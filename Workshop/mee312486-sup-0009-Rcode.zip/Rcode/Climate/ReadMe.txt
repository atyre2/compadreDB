These files are part of the Teller et al MEE Manuscript, 
"Linking Demography with Drivers"

In the climate folder, Authetic Analysis and Artificial 
Analysis are the same except for the source of the data. 
The supplement to the manuscript extensively describes 
the climate subfolders. Please start there.



