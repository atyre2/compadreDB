These scripts and data accompany the manuscript Teller et al 

MEE, "Linking Demography with Drivers: Competition and Climate"

All of the scripts depend on being unzipped onto the hardrive

and the directing R to the folder. Please use ReadMe.txts for 

directions for each driver, climate and competition.